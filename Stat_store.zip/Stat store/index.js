function addbill() {                                                                                                                                                                                                                                                
    tb=document.getElementById('1').value*20+document.getElementById('2').value*45+document.getElementById('3').value*10+document.getElementById('4').value*30+document.getElementById('5').value*25+document.getElementById('6').value*20
    localStorage.setItem('bill',tb)
}