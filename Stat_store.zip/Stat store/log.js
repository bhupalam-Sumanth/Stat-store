function lval() {

    var cred = [['sumanth','1234']];
        var retVal = confirm("Are you sure want to submit?");
  
  
        var userName = document.getElementById('usn').value;
        var password = document.getElementById('psd').value;
  
        if(retVal == true){
          var flag = 0;
  
          for (var i = 0; i < cred.length; i++) {
            if(cred[i][0] === userName && cred[i][1] === password){
              flag=1;
              break
            }
          }
          if(flag === 1){
            document.location.href = 'stat1.html'
          }
          else{
            retVal = confirm("Details Mismatch!!\n Please Try entering correct credentials");
            if (retVal == true) {
              document.location.href = 'log.html'
            }
          }
    
        }else{
          document.location.href = 'log.html'
        }
  }